---
type: location
name: Grandmother's Cottage
modified: 2026-04-04T10:29:25.010Z
---

