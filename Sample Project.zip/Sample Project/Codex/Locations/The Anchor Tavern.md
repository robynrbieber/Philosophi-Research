---
type: location
name: The Anchor Tavern
modified: 2026-04-04T10:29:25.012Z
---

