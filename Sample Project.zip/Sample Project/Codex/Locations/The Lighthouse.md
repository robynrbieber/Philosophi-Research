---
type: location
name: The Lighthouse
modified: 2026-04-04T10:29:25.012Z
---

