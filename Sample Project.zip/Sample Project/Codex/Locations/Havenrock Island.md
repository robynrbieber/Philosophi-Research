---
type: location
name: Havenrock Island
description: A small, rugged island off the Cornish coast, accessible only by ferry or private boat. Rocky cliffs, hidden coves, a single harbor, and a 19th-century lighthouse define the landscape. Once a thriving fishing community, it's now caught between preservation and a controversial resort development.
modified: 2026-04-04T10:29:25.012Z
---

