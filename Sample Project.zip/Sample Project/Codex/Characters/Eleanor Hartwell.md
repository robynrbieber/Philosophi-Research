---
type: character
name: Eleanor Hartwell
age: '78'
role: Mentor
personality: Warm, artistic, quietly courageous. Spent her life protecting her family while carrying an unbearable secret.
internalMotivation: Ensure the truth survives her.
strengths: Artistic brilliance, Patient strategic thinking, Deep love for family
flaws: Fear of Blackwood family, Carried guilt for her silence, Isolation from keeping the secret
custom:
  cause_of_death: Heart failure — the island doctor said she simply stopped fighting
  final_words: 'Spoken to Maggie: ''The paintings will explain everything'''
  appearance: 'In photographs: kind face, silver-white hair, paint-stained fingers, always wearing Thomas''s wedding ring on a chain around her neck'
  arc: Revealed through flashbacks and artifacts. Her arc is one of silent resistance — she couldn't speak the truth aloud, so she embedded it in her art.
  status: Deceased
  tags: mentor, deceased, artist, family-secrets
  gender: Female
  motivation: Ensure the truth survives her.
  occupation: Former painter / island historian
  studio: '#GrandmothersCottage attic — untouched since her death'
  backstory: Eleanor discovered the truth about Thomas's murder shortly after it happened but was threatened by Algernon Blackwood into silence. She spent decades painting the lighthouse and the harbor — her canvases contain hidden clues she hoped someone would eventually decode. She wrote the letter that sets the story in motion.
  locations: '#HavenrockIsland, #GrandmothersCottage, #TheLighthouse'
  residency: Grandmother's Cottage, Havenrock Island
  signature_color: Cobalt blue — present in every one of her paintings
  props: '#EleanorsLetter, #LighthousePainting, #ThomasRing, #PaintBox'
modified: 2026-04-04T10:29:25.001Z
---

