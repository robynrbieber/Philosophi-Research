---
type: character
name: Maggie Shaw
age: '72'
role: Supporting
personality: Warm but evasive. Sharp memory she deploys selectively. Carries the weight of complicit silence — she knew more than she told and has lived with that guilt for decades.
internalMotivation: Protect Eleanor's memory, but ultimately honor the truth.
strengths: Knows everyone's secrets, Trusted by the whole island, Fierce when cornered
flaws: Guilt over her silence, Protective to a fault, Health is failing
custom:
  props: '#TeaSet, #OldPhotographs'
  quirk: Offers tea before answering any question
  residency: Havenrock Island
  tags: supporting, secrets, guilt, witness
  arc: From keeper of secrets to truth-teller. Her confession in Act 3 is the emotional climax of the story.
  backstory: Best friend of Eleanor Hartwell since childhood. She was the last person to see Thomas alive, though she's never told anyone. A beloved schoolteacher who taught three generations of island children, including Jack Mercer.
  appearance: Small, wiry, silver hair in a bun, reading glasses on a chain, always in a hand-knit cardigan, surprisingly strong grip
  fear: Dying before she can set things right
  garden: Prize-winning roses — the only thing she can fully control
  motivation: Protect Eleanor's memory, but ultimately honor the truth.
  locations: '#HavenrockIsland, #TheAnchorTavern, #GrandmothersCottage'
  memory: The sound of Thomas's boat engine the night he left
  gender: Female
  occupation: Retired schoolteacher
modified: 2026-04-04T10:29:25.005Z
---

