---
type: character
name: Emma Hartwell
age: '32'
role: Protagonist
personality: Tenacious, empathetic, restless. Hides vulnerability behind dry humor. Struggles with trust but deeply loyal once committed.
internalMotivation: Find out what really happened to her grandfather Thomas.
strengths: Sharp instincts, Skilled interviewer, Refuses to give up
flaws: Emotionally guarded, Tendency to push people away, Impatient with small-town politics
custom:
  quirk: Talks to herself when thinking through a problem
  arc: From detached outsider to someone who belongs. Learns that truth isn't always about exposure — sometimes it's about healing.
  gender: Female
  occupation: Investigative journalist
  locations: '#HavenrockIsland, #GrandmothersCottage, #TheLighthouse'
  drink: Black coffee, always
  props: '#EleanorsLetter, #ThomasRing, #OldCamera'
  appearance: Tall, auburn hair often tied back, green eyes, freckles across the nose, usually in a worn leather jacket and boots
  tags: mystery, homecoming, family-secrets, journalist
  motivation: Find out what really happened to her grandfather Thomas.
  backstory: Grew up spending summers on Havenrock Island with her grandparents. Left for London at 18 and never looked back — until now. A rising journalist at The Herald, she's used to chasing other people's stories but has never investigated her own family's secrets.
  residency: London (originally Havenrock Island)
  notebook: '#MoleskineNotebook — carries it everywhere'
  fear: That the truth will destroy what little family memory she has left
  theme_song: The Chain — Fleetwood Mac
modified: 2026-04-04T10:29:25.001Z
---

