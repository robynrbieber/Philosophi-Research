---
type: character
name: Thomas Hartwell
age: '45'
role: Supporting
personality: Honest, stubborn, principled. The kind of man who couldn't look the other way when he discovered Algernon Blackwood's land fraud. That integrity cost him his life.
internalMotivation: Protect the islanders from Blackwood's fraud.
strengths: Moral courage, Deep knowledge of island history, Respected by everyone
flaws: Too trusting, Confronted Algernon alone, Left no backup plan
custom:
  tags: deceased, mystery, victim, family-secrets
  cause_of_death: Murdered by Algernon Blackwood — staged as drowning
  locations: '#HavenrockIsland, #TheHarbor, #TheLighthouse'
  last_seen: The Harbor, evening of August 14, 1982
  discovery: His wedding ring washes up inside a bottle — the event that prompted Eleanor's letter
  gender: Male
  occupation: Fisherman / amateur historian
  motivation: Protect the islanders from Blackwood's fraud.
  props: '#ThomasRing, #ForgedDeeds, #FishingKnife'
  appearance: 'In photographs: strong jaw, kind eyes, calloused hands, always in a fisherman''s cap, wedding ring never removed'
  legacy: Emma's story about him becomes a tribute, not an expose
  residency: Grandmother's Cottage, Havenrock Island
  backstory: Thomas was a respected fisherman and amateur historian of Havenrock Island. In the summer of 1982, he discovered that Algernon Blackwood had been forging land deeds to seize coastal properties from local families. When Thomas confronted Algernon, he was murdered and his death staged as a drowning. His body was weighted down in the caves beneath the lighthouse.
  arc: Revealed posthumously. Thomas represents the ordinary person who stood up against corruption. His story is the moral center of the novel.
  status: Deceased (murdered 1982)
modified: 2026-04-04T10:29:25.006Z
---

