---
type: character
name: Jack Mercer
age: '35'
role: Deuteragonist
personality: Quiet, observant, dependable. Slow to open up but fiercely protective. Carries guilt about things he's seen but never reported.
internalMotivation: Honor his father's memory by finishing what Robert started.
strengths: Knows every inch of the island, Physically capable, Trustworthy
flaws: Avoids confrontation, Carries survivor's guilt, Distrusts outsiders (initially)
custom:
  motivation: Honor his father's memory by finishing what Robert started.
  props: '#FathersLogbook, #FishingKnife'
  boat_name: The Skylark — inherited from his father
  occupation: Fisherman / boat mechanic
  gender: Male
  residency: Havenrock Island
  tags: mystery, trust, romance, local
  quirk: Whittles driftwood when thinking
  arc: From silent bystander to someone who acts. Learns that loyalty to the island means standing up for the truth, not staying quiet.
  appearance: Broad-shouldered, weather-beaten tan, dark curly hair, calloused hands, usually in a cable-knit sweater and waterproofs
  fear: That speaking up will put Emma in danger
  locations: '#HavenrockIsland, #TheHarbor, #TheLighthouse'
  backstory: Third-generation fisherman on Havenrock. His father Robert saw something the night Thomas Hartwell disappeared but died before telling anyone. Jack found cryptic notes in his father's logbook and has been quietly piecing things together for years.
  favorite_spot: '#TheLighthouse cliffs at dawn'
modified: 2026-04-04T10:29:25.003Z
---

