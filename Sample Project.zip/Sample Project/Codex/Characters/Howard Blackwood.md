---
type: character
name: Howard Blackwood
age: '58'
role: Antagonist
personality: Charming in public, ruthless in private. Controls through influence rather than force. Believes the island's future — and his family's legacy — depends on keeping the past buried.
internalMotivation: Protect the Blackwood name and complete the resort deal.
strengths: Political connections, Wealth and influence, Expert manipulator
flaws: Arrogance, Underestimates Emma, Haunted by guilt he won't admit
custom:
  quirk: Adjusts his signet ring when lying
  residency: Blackwood Manor, Havenrock Island
  arc: From untouchable power broker to exposed fraud. His carefully constructed world crumbles as Emma uncovers the truth.
  motivation: Protect the Blackwood name and complete the resort deal.
  appearance: Silver-haired, immaculately dressed even in a coastal village, sharp blue eyes, imposing posture, gold signet ring
  occupation: Island commissioner / landowner
  locations: '#HavenrockIsland, #BlackwoodManor, #TheAnchorTavern'
  vehicle: Black Range Rover — only modern car on the island
  wine: Single malt Scotch, never wine
  props: '#SignetRing, #AlgernonsJournal, #ResortPlans'
  tags: antagonist, politics, corruption, power
  gender: Male
  backstory: Grandson of Algernon Blackwood, who murdered Thomas Hartwell over a land fraud scheme in 1982. Howard inherited both the estate and the secret. He's spent decades positioning himself as the island's benefactor while quietly buying up coastal properties for a luxury resort development.
  fear: Being seen as his grandfather was — a murderer
modified: 2026-04-04T10:29:25.002Z
---

