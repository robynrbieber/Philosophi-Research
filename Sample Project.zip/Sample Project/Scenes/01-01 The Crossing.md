---
type: scene
title: The Crossing
act: 1
chapter: 1
sequence: 1
pov: Emma Hartwell
characters:
- Emma Hartwell
- Jack Mercer
location: The Harbor
status: idea
intensity: 3
tags:
- mystery
- homecoming
- arrival
payoff_scenes:
- The Letter
- Jack's Secret
wordcount: 210
target_wordcount: 2500
notes: Opening scene. Establish mood, island setting, Emma's emotional state. First glimpse of Jack at the harbor.
modified: 2026-04-04T11:37:25.911Z
---

The ferry rounded the headland and Havenrock Island appeared through the mist — a dark ridge of rock and gorse, crowned by the silhouette of The Lighthouse.
Emma Hartwell hadn't been back in fifteen years. Not since the summer she turned seventeen, when her grandmother Eleanor had pressed a paintbrush into her hand and said,*"This island will always be here for you."*
Now Eleanor was dead, and here Emma was — not for the island, but for the cottage, the will, and whatever else needed sorting before she could get back to London.
The ferry bumped against the quay at The Harbor. A handful of passengers shuffled off. Emma slung her bag over her shoulder and stepped onto wet stone.
A man was coiling rope on the dock. Dark curly hair, cable-knit sweater, hands that looked like they'd never seen an office. He glanced up as she passed.
"Hartwell?" he said.
She stopped. "Do I know you?"
"No." He went back to his rope. "But I knew your grandmother."
She watched him for a moment, then walked on. The wind carried the smell of salt and diesel, and underneath it something else — something she couldn't name but recognized immediately.
The feeling of coming home to a place that didn't want her back.