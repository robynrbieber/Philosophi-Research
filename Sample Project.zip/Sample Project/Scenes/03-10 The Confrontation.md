---
type: scene
title: The Confrontation
act: 3
chapter: 9
sequence: 10
status: idea
pov: Emma Hartwell
location: The Lighthouse
characters:
  - Emma Hartwell
  - Jack Mercer
  - Howard Blackwood
intensity: 10
tags:
  - climax
  - confrontation
  - justice
  - danger
wordTarget: 3000
notes: The climax. Emma confronts Howard at the lighthouse with all the evidence — the letter, the paintings, the logbook, Algernon's journal. Howard's façade cracks. He didn't commit the murder, but he's spent his life covering it up. Jack is there as backup. The police boat is already on its way.
setup_scenes:
  - The Warning
  - Jack's Secret
  - The Storm
  - Breaking In
payoff_scenes:
  - Maggie's Confession
  - The Aftermath
modified: 2026-04-04
wordcount: 0
---

