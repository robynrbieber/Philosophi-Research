---
type: scene
title: Maggie's Confession
act: 3
chapter: 9
sequence: 12
status: idea
pov: Maggie Shaw
location: Grandmother's Cottage
characters:
  - Maggie Shaw
  - Emma Hartwell
intensity: 8
tags:
  - revelation
  - forgiveness
  - truth
  - emotional
wordTarget: 2000
notes: Emotional climax. After Howard's arrest, Maggie finally tells Emma the full truth — she saw Thomas alive that night. She watched him walk toward the lighthouse. She could have stopped him. She's carried that guilt for forty years. Emma forgives her. Maggie gives Emma the old photographs of Thomas and Eleanor together.
setup_scenes:
  - What Maggie Knows
  - The Last Good Summer
  - The Confrontation
payoff_scenes:
  - The Aftermath
modified: 2026-04-04
wordcount: 0
---

