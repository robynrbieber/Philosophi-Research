---
type: location
name: The Lighthouse
created: 2026-02-22
modified: 2026-02-22
world: Havenrock Island
---
